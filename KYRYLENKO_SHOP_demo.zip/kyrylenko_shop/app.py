import hashlib
import hmac
import json
import os
import sqlite3
import time
from pathlib import Path
from urllib.parse import parse_qsl

from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, Depends
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = os.getenv("DATABASE_PATH", str(BASE_DIR / "kyrylenko_shop.db"))
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
DEMO_MODE = os.getenv("DEMO_MODE", "true").lower() == "true"
ADMIN_KEY = os.getenv("ADMIN_KEY", "change-this-admin-key")

app = FastAPI(title="KYRYLENKO SHOP", version="0.1.0")
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")


def connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with connect() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_user_id TEXT NOT NULL,
                username TEXT NOT NULL,
                product_type TEXT NOT NULL,
                quantity TEXT NOT NULL,
                total_uah REAL,
                status TEXT NOT NULL DEFAULT 'demo_pending',
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        """)
        defaults = {
            "stars_price_per_100": "60",
            "markup_percent": "10",
            "premium_3m": "",
            "premium_6m": "",
            "premium_12m": "",
            "support_username": ""
        }
        for key, value in defaults.items():
            con.execute(
                "INSERT OR IGNORE INTO settings(key, value) VALUES(?, ?)",
                (key, value)
            )


init_db()


def get_settings():
    with connect() as con:
        rows = con.execute("SELECT key, value FROM settings").fetchall()
    return {row["key"]: row["value"] for row in rows}


def save_settings(values: dict):
    allowed = {
        "stars_price_per_100", "markup_percent",
        "premium_3m", "premium_6m", "premium_12m",
        "support_username"
    }
    with connect() as con:
        for key, value in values.items():
            if key in allowed:
                con.execute(
                    "INSERT INTO settings(key, value) VALUES(?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (key, str(value))
                )


def validate_webapp_init_data(init_data: str):
    """Validate Telegram Mini App initData using the official bot-token HMAC scheme."""
    if not BOT_TOKEN:
        raise HTTPException(status_code=401, detail="Bot token is not configured")
    try:
        parsed = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = parsed.pop("hash", None)
        if not received_hash:
            raise ValueError("Missing hash")
        data_check_string = "\n".join(
            f"{key}={value}" for key, value in sorted(parsed.items())
        )
        secret_key = hmac.new(
            b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256
        ).digest()
        calculated_hash = hmac.new(
            secret_key, data_check_string.encode(), hashlib.sha256
        ).hexdigest()
        if not hmac.compare_digest(calculated_hash, received_hash):
            raise ValueError("Invalid signature")
        auth_date = int(parsed.get("auth_date", "0"))
        if time.time() - auth_date > 86400:
            raise ValueError("Expired initData")
        user = json.loads(parsed.get("user", "{}"))
        if not user.get("id"):
            raise ValueError("Missing Telegram user")
        return str(user["id"]), user.get("username") or user.get("first_name") or "Telegram user"
    except Exception:
        raise HTTPException(status_code=401, detail="Telegram authorization failed")


def current_user(x_telegram_init_data: str = Header(default="")):
    if x_telegram_init_data:
        return validate_webapp_init_data(x_telegram_init_data)
    if DEMO_MODE:
        return "demo-user", "Demo user"
    raise HTTPException(status_code=401, detail="Open this app through Telegram")


def require_admin(x_admin_key: str = Header(default="")):
    if not ADMIN_KEY or ADMIN_KEY == "change-this-admin-key":
        raise HTTPException(status_code=503, detail="Set a private ADMIN_KEY in .env first")
    if not hmac.compare_digest(x_admin_key, ADMIN_KEY):
        raise HTTPException(status_code=403, detail="Admin access denied")
    return True


def price_stars(amount: int):
    settings = get_settings()
    base_per_100 = float(settings.get("stars_price_per_100", "60"))
    markup = float(settings.get("markup_percent", "10"))
    return round((amount / 100) * base_per_100 * (1 + markup / 100), 2)


class OrderIn(BaseModel):
    product_type: str = Field(pattern="^(stars|premium)$")
    quantity: str = Field(min_length=1, max_length=20)
    recipient_username: str = Field(min_length=2, max_length=32, pattern="^[A-Za-z0-9_@]+$")


class SettingsIn(BaseModel):
    stars_price_per_100: float = Field(ge=0, le=100000)
    markup_percent: float = Field(ge=0, le=100)
    premium_3m: str = Field(default="", max_length=20)
    premium_6m: str = Field(default="", max_length=20)
    premium_12m: str = Field(default="", max_length=20)
    support_username: str = Field(default="", max_length=40)


class StatusIn(BaseModel):
    status: str = Field(pattern="^(demo_pending|processing|completed|cancelled|price_needed)$")


@app.get("/")
def index():
    return FileResponse(BASE_DIR / "static" / "index.html")


@app.get("/admin")
def admin_page():
    return FileResponse(BASE_DIR / "static" / "admin.html")


@app.get("/health")
def health():
    return {"ok": True, "app": "KYRYLENKO SHOP", "mode": "demo" if DEMO_MODE else "telegram-auth"}


@app.get("/api/catalog")
def catalog():
    settings = get_settings()
    stars_options = [100, 250, 500, 1000]
    stars = [
        {
            "quantity": amount,
            "price_uah": price_stars(amount),
            "label": f"{amount} Stars"
        }
        for amount in stars_options
    ]
    premium = []
    for months in (3, 6, 12):
        raw = settings.get(f"premium_{months}m", "")
        premium.append({
            "months": months,
            "price_uah": float(raw) if raw.strip() else None,
            "label": f"Premium на {months} месяцев"
        })
    return {
        "brand": "KYRYLENKO SHOP",
        "stars": stars,
        "premium": premium,
        "ton": {
            "available": False,
            "message": "Раздел TON пока информационный. Реальные операции и кошельки не подключены."
        },
        "pricing": {
            "stars_price_per_100": float(settings.get("stars_price_per_100", "60")),
            "markup_percent": float(settings.get("markup_percent", "10"))
        },
        "support_username": settings.get("support_username", ""),
        "notice": "Демонстрационный каталог. Заказы не являются покупкой и не принимают оплату."
    }


@app.post("/api/orders")
def create_order(order: OrderIn, user=Depends(current_user)):
    user_id, _ = user
    username = order.recipient_username.lstrip("@")
    if len(username) < 2:
        raise HTTPException(status_code=400, detail="Telegram username is too short")
    if order.product_type == "stars":
        try:
            quantity = int(order.quantity)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid Stars amount")
        if quantity not in (100, 250, 500, 1000):
            raise HTTPException(status_code=400, detail="Choose an available Stars package")
        total = price_stars(quantity)
        status = "demo_pending"
        quantity_label = str(quantity)
    else:
        if order.quantity not in ("3", "6", "12"):
            raise HTTPException(status_code=400, detail="Choose 3, 6 or 12 months")
        settings = get_settings()
        raw = settings.get(f"premium_{order.quantity}m", "")
        total = float(raw) if raw.strip() else None
        status = "price_needed" if total is None else "demo_pending"
        quantity_label = f"{order.quantity} months"

    with connect() as con:
        cur = con.execute(
            """INSERT INTO orders
            (telegram_user_id, username, product_type, quantity, total_uah, status)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (user_id, username, order.product_type, quantity_label, total, status)
        )
        order_id = cur.lastrowid

    return {
        "ok": True,
        "order_id": order_id,
        "status": status,
        "total_uah": total,
        "message": "Тестовая заявка создана. Оплата и выдача товара не выполняются."
    }


@app.get("/api/my-orders")
def my_orders(user=Depends(current_user)):
    user_id, _ = user
    with connect() as con:
        rows = con.execute(
            """SELECT id, product_type, quantity, total_uah, status, created_at
            FROM orders WHERE telegram_user_id=? ORDER BY id DESC LIMIT 30""",
            (user_id,)
        ).fetchall()
    return [dict(row) for row in rows]


@app.get("/api/admin/orders", dependencies=[Depends(require_admin)])
def admin_orders():
    with connect() as con:
        rows = con.execute(
            """SELECT id, telegram_user_id, username, product_type, quantity,
            total_uah, status, created_at FROM orders ORDER BY id DESC LIMIT 200"""
        ).fetchall()
    return [dict(row) for row in rows]


@app.patch("/api/admin/orders/{order_id}", dependencies=[Depends(require_admin)])
def update_order(order_id: int, body: StatusIn):
    with connect() as con:
        cur = con.execute(
            "UPDATE orders SET status=? WHERE id=?",
            (body.status, order_id)
        )
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Order not found")
    return {"ok": True}


@app.get("/api/admin/settings", dependencies=[Depends(require_admin)])
def admin_settings():
    return get_settings()


@app.put("/api/admin/settings", dependencies=[Depends(require_admin)])
def update_settings(body: SettingsIn):
    save_settings(body.model_dump())
    return {"ok": True, "settings": get_settings()}
