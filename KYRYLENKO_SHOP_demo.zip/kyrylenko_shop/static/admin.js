let adminKey="";
function adminHeaders(){return {"Content-Type":"application/json","X-Admin-Key":adminKey};}
function adminToast(text){const el=document.getElementById("admin-toast");el.textContent=text;el.style.display="block";setTimeout(()=>el.style.display="none",2500);}
async function adminApi(url,options={}){const r=await fetch(url,{...options,headers:{...adminHeaders(),...(options.headers||{})}});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.detail||"Ошибка");return d;}
async function login(){
  adminKey=document.getElementById("admin-key").value.trim();
  try{
    const s=await adminApi("/api/admin/settings");
    document.getElementById("login-card").hidden=true;
    document.getElementById("admin-content").hidden=false;
    document.getElementById("stars-price").value=s.stars_price_per_100;
    document.getElementById("markup").value=s.markup_percent;
    document.getElementById("premium-3").value=s.premium_3m;
    document.getElementById("premium-6").value=s.premium_6m;
    document.getElementById("premium-12").value=s.premium_12m;
    document.getElementById("support").value=s.support_username;
    await loadOrders();
  }catch(e){adminToast(e.message);}
}
async function saveSettings(){
  try{
    const body={
      stars_price_per_100:Number(document.getElementById("stars-price").value),
      markup_percent:Number(document.getElementById("markup").value),
      premium_3m:document.getElementById("premium-3").value,
      premium_6m:document.getElementById("premium-6").value,
      premium_12m:document.getElementById("premium-12").value,
      support_username:document.getElementById("support").value.trim().replace(/^@/,"")
    };
    await adminApi("/api/admin/settings",{method:"PUT",body:JSON.stringify(body)});
    adminToast("Настройки сохранены");
  }catch(e){adminToast(e.message);}
}
async function loadOrders(){
  try{
    const orders=await adminApi("/api/admin/orders");
    const box=document.getElementById("admin-orders");
    if(!orders.length){box.innerHTML='<div class="empty-state">Пока нет заявок</div>';return;}
    box.innerHTML=orders.map(o=>`<div class="admin-order"><b>Заявка #${o.id}</b> · ${o.product_type==="stars"?"⭐ Stars":"💎 Premium"}<br><small>@${escapeHtml(o.username)} · ${escapeHtml(o.quantity)} · ${o.total_uah===null?"Цена уточняется":o.total_uah+" грн"} · ${escapeHtml(o.created_at)}</small><select onchange="changeStatus(${o.id},this.value)"><option value="demo_pending" ${o.status==="demo_pending"?"selected":""}>Тестовая</option><option value="price_needed" ${o.status==="price_needed"?"selected":""}>Цена уточняется</option><option value="processing" ${o.status==="processing"?"selected":""}>В обработке</option><option value="completed" ${o.status==="completed"?"selected":""}>Завершена</option><option value="cancelled" ${o.status==="cancelled"?"selected":""}>Отменена</option></select></div>`).join("");
  }catch(e){adminToast(e.message);}
}
async function changeStatus(id,status){
  try{await adminApi(`/api/admin/orders/${id}`,{method:"PATCH",body:JSON.stringify({status})});adminToast("Статус обновлён");}
  catch(e){adminToast(e.message);}
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
