const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); }
const initData = tg?.initData || "";
const headers = {"Content-Type":"application/json"};
if (initData) headers["X-Telegram-Init-Data"] = initData;
let catalog = null;
let selectedType = "stars";
let selectedQuantity = "100";

function money(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return "Уточняется";
  return new Intl.NumberFormat("ru-RU",{maximumFractionDigits:2}).format(Number(value)) + " грн";
}
function toast(message) {
  const el=document.getElementById("toast"); el.textContent=message; el.style.display="block";
  setTimeout(()=>el.style.display="none",2600);
}
function navigate(page) {
  document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
  document.getElementById("page-"+page).classList.add("active");
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  if(page==="profile") loadMyOrders();
  window.scrollTo({top:0,behavior:"smooth"});
}
async function api(url, options={}) {
  const response=await fetch(url,{...options,headers:{...headers,...(options.headers||{})}});
  const data=await response.json().catch(()=>({}));
  if(!response.ok) throw new Error(data.detail||"Ошибка запроса");
  return data;
}
async function loadCatalog() {
  try {
    catalog=await api("/api/catalog");
    document.getElementById("featured-price").textContent=money(catalog.stars[0].price_uah);
    calculate();
    const support=catalog.support_username;
    if(support) {
      const link=document.getElementById("support-link");
      link.href="https://t.me/"+support; link.hidden=false;
    }
  } catch(e) { toast(e.message); }
}
function showProducts(type) {
  selectedType=type;
  const list=document.getElementById("product-list"); list.innerHTML="";
  if(type==="stars") {
    document.getElementById("products-title").textContent="Telegram Stars";
    document.getElementById("products-subtitle").textContent="Выбери количество звёзд";
    catalog.stars.forEach(item=>{
      const card=document.createElement("div"); card.className="product-card";
      card.innerHTML=`<div class="product-symbol">⭐</div><b>${item.label}</b><div class="product-price">${money(item.price_uah)}</div><div class="product-note">Демонстрационная цена</div><button class="mini-buy">Выбрать</button>`;
      card.querySelector("button").onclick=()=>openOrder("stars",String(item.quantity));
      list.appendChild(card);
    });
  } else {
    document.getElementById("products-title").textContent="Telegram Premium";
    document.getElementById("products-subtitle").textContent="Выбери срок подписки";
    catalog.premium.forEach(item=>{
      const card=document.createElement("div"); card.className="product-card";
      card.innerHTML=`<div class="product-symbol">💎</div><b>${item.label}</b><div class="product-price">${money(item.price_uah)}</div><div class="product-note">${item.price_uah===null?"Цена настраивается администратором":"Демонстрационная цена"}</div><button class="mini-buy">Оставить заявку</button>`;
      card.querySelector("button").onclick=()=>openOrder("premium",String(item.months));
      list.appendChild(card);
    });
  }
  navigate("products");
}
function showTonInfo() {
  document.getElementById("products-title").textContent="Раздел TON";
  document.getElementById("products-subtitle").textContent="Информация";
  document.getElementById("product-list").innerHTML=`<div class="ton-info" style="grid-column:1/-1"><div style="font-size:32px">💠</div><b>TON</b><p>${catalog?.ton?.message||"Раздел находится в разработке."}</p><p>Не подключай кошелёк и не отправляй seed-фразы в демонстрационной версии.</p></div>`;
  navigate("products");
}
function calculate() {
  const amount=Number(document.getElementById("calc-amount").value||0);
  if(!catalog || amount<=0 || amount>1000000) {document.getElementById("calc-price").textContent="—";return;}
  const basePer100=Number(catalog.pricing?.stars_price_per_100 ?? 60);
  const markup=Number(catalog.pricing?.markup_percent ?? 10);
  document.getElementById("calc-price").textContent=money(amount/100*basePer100*(1+markup/100));
}
async function loadCalculatorSettings() { calculate(); }
function openOrder(type, quantity) {
  selectedType=type; selectedQuantity=String(quantity);
  const productName=type==="stars"?`${quantity} Telegram Stars`:`Telegram Premium на ${quantity} месяцев`;
  let price="Уточняется";
  if(type==="stars") {
    const item=catalog.stars.find(x=>String(x.quantity)===String(quantity)); price=money(item?.price_uah);
  } else {
    const item=catalog.premium.find(x=>String(x.months)===String(quantity)); price=money(item?.price_uah);
  }
  document.getElementById("modal-product").textContent=productName;
  document.getElementById("modal-price").textContent=price;
  document.getElementById("recipient").value="";
  document.getElementById("order-modal").classList.add("open");
}
function closeOrder(){document.getElementById("order-modal").classList.remove("open");}
async function submitOrder() {
  const username=document.getElementById("recipient").value.trim().replace(/^@/,"");
  if(!/^[A-Za-z0-9_]{2,32}$/.test(username)){toast("Введи корректный Telegram username");return;}
  const button=document.getElementById("submit-order"); button.disabled=true; button.textContent="Создаём…";
  try {
    const result=await api("/api/orders",{method:"POST",body:JSON.stringify({
      product_type:selectedType,quantity:selectedQuantity,recipient_username:username
    })});
    closeOrder();
    toast("Тестовая заявка №"+result.order_id+" создана");
    navigate("profile");
  } catch(e) {toast(e.message);}
  finally {button.disabled=false;button.textContent="Создать заявку";}
}
async function loadMyOrders() {
  const box=document.getElementById("my-orders");
  try {
    const orders=await api("/api/my-orders");
    if(!orders.length){box.innerHTML='<div class="empty-state">Здесь появятся твои тестовые заявки</div>';return;}
    box.innerHTML=orders.map(o=>`<div class="order-row"><div class="order-row-top"><b>Заявка #${o.id}</b><span class="status">${statusName(o.status)}</span></div><div>${o.product_type==="stars"?"⭐ Stars":"💎 Premium"} · ${o.quantity}</div><small>${o.total_uah===null?"Цена уточняется":money(o.total_uah)} · ${o.created_at}</small></div>`).join("");
  } catch(e){box.innerHTML='<div class="empty-state">Открой приложение через Telegram или включи демо-режим для локального просмотра</div>';}
}
function statusName(s){return ({demo_pending:"Тестовая",price_needed:"Цена уточняется",processing:"В обработке",completed:"Завершена",cancelled:"Отменена"})[s]||s;}
const displayName=tg?.initDataUnsafe?.user?.first_name || "Покупатель";
document.getElementById("profile-name").textContent=displayName;
document.getElementById("avatar").textContent=(displayName[0]||"K").toUpperCase();
document.getElementById("profile-avatar").textContent=(displayName[0]||"K").toUpperCase();
loadCatalog().then(loadCalculatorSettings);
