import asyncio
import os

from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton, WebAppInfo
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
WEBAPP_URL = os.getenv("WEBAPP_URL", "").strip()

dp = Dispatcher()


@dp.message(Command("start"))
async def start(message: Message):
    if WEBAPP_URL.startswith("https://"):
        keyboard = ReplyKeyboardMarkup(
            keyboard=[[
                KeyboardButton(
                    text="🛍 Відкрити KYRYLENKO SHOP",
                    web_app=WebAppInfo(url=WEBAPP_URL)
                )
            ]],
            resize_keyboard=True
        )
        await message.answer(
            "Вітаємо в KYRYLENKO SHOP!\n\n"
            "Відкрий демо-магазин кнопкою нижче. У цій версії можна "
            "переглядати каталог і створювати тестові заявки. Оплата "
            "та видача товарів не виконуються.",
            reply_markup=keyboard
        )
    else:
        await message.answer(
            "KYRYLENKO SHOP запущено в режимі налаштування.\n"
            "Додай HTTPS-посилання Mini App у WEBAPP_URL файлу .env."
        )


@dp.message(Command("terms"))
async def terms(message: Message):
    await message.answer(
        "Умови демо-версії: заявки тестові, оплата та доставка цифрових "
        "товарів не здійснюються. Не надсилайте паролі, коди входу, "
        "дані банківських карток або seed-фрази."
    )


@dp.message(Command("support", "paysupport"))
async def support(message: Message):
    await message.answer(
        "Підтримка KYRYLENKO SHOP: звернення щодо демонстраційної версії "
        "можна надіслати адміністратору магазину."
    )


async def main():
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN is empty. Add your token to .env")
    bot = Bot(BOT_TOKEN)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
